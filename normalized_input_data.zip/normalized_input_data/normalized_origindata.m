clear;clc;close all;
for season=1:5
% season(1:5)=[fall, winter, spring, summer, annualmean]
    clearvars -except season

cd('...\original_input_data');
load(['cross_original_data_0.2regulargrid_season',num2str(season),'.mat'],...
    'Leddy','eddyvelmag','cw_u','gamma0','Lmix','xc','yc');
%Lmix=Lmix_particle
p1_0=Leddy;clear Leddy;
p2_0=eddyvelmag;clear eddyvelmag;
p3_0=cw_u;clear cw_u;
p4_0=gamma0;clear gamma0;
y_0=Lmix;clear Lmix;

% normalization methods 
%min-max:
p1_1=(p1_0-min(p1_0(:)))./(max(p1_0(:))-min(p1_0(:)));p1(:,:,1)=p1_1;
p2_1=(p2_0-min(p2_0(:)))./(max(p2_0(:))-min(p2_0(:)));p2(:,:,1)=p2_1;
p3_1=(p3_0-min(p3_0(:)))./(max(p3_0(:))-min(p3_0(:)));p3(:,:,1)=p3_1;
p4_1=(p4_0-min(p4_0(:)))./(max(p4_0(:))-min(p4_0(:)));p4(:,:,1)=p4_1;
y_1=(y_0-min(y_0(:)))./(max(y_0(:))-min(y_0(:)));y(:,:,1)=y_1;

%arctan:
p1_2=atan(p1_0).*2./pi;p1(:,:,2)=p1_2;
p2_2=atan(p2_0).*2./pi;p2(:,:,2)=p2_2;
p3_2=atan(p3_0).*2./pi;p3(:,:,2)=p3_2;
p4_2=atan(p4_0).*2./pi;p4(:,:,2)=p4_2;
y_2=atan(y_0).*2./pi;y(:,:,2)=y_2;

%Z-score: % we used this finally after comparing the predictions
p1_3=(p1_0-nanmean(p1_0(:)))./nanstd(p1_0(:));p1(:,:,3)=p1_3;
p2_3=(p2_0-nanmean(p2_0(:)))./nanstd(p2_0(:));p2(:,:,3)=p2_3;
p3_3=(p3_0-nanmean(p3_0(:)))./nanstd(p3_0(:));p3(:,:,3)=p3_3;
p4_3=(p4_0-nanmean(p4_0(:)))./nanstd(p4_0(:));p4(:,:,3)=p4_3;
y_3=(y_0-nanmean(y_0(:)))./nanstd(y_0(:));y(:,:,3)=y_3;

%mean:
p1_4=(p1_0-nanmean(p1_0(:)))./(max(p1_0(:))-min(p1_0(:)));p1(:,:,4)=p1_4;
p2_4=(p2_0-nanmean(p2_0(:)))./(max(p2_0(:))-min(p2_0(:)));p2(:,:,4)=p2_4;
p3_4=(p3_0-nanmean(p3_0(:)))./(max(p3_0(:))-min(p3_0(:)));p3(:,:,4)=p3_4;
p4_4=(p4_0-nanmean(p4_0(:)))./(max(p4_0(:))-min(p4_0(:)));p4(:,:,4)=p4_4;
y_4=(y_0-nanmean(y_0(:)))./(max(y_0(:))-min(y_0(:)));y(:,:,4)=y_4;

cd('...\normalized_input_data');
if season==1
save(['normalized_input_data_fall.mat'],'p1','p2','p3',...
    'p4','y','xc','yc');
elseif season==2
save(['normalized_input_data_winter.mat'],'p1','p2','p3',...
    'p4','y','xc','yc');
elseif season==3
save(['normalized_input_data_spring.mat'],'p1','p2','p3',...
    'p4','y','xc','yc');
elseif season==4
save(['normalized_input_data_summer.mat'],'p1','p2','p3',...
    'p4','y','xc','yc');
elseif season==5
save(['normalized_input_data_annualmean.mat'],'p1','p2','p3',...
    'p4','y','xc','yc');
end