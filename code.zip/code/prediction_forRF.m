%The modeling was done with Matlab software version R2019a.
% and used RF_MexStandalone-v0.02 program package.
%(https://storage.googleapis.com/google-code-archive-downloads/v2/code.google.com/randomforest-matlab/Windows-Precompiled-RF_MexStandalone-v0.02-.zip)
clear;clc;close all;
for season=1:5
for choice=1:5
    % choice==1;remove leddy
    % choice==2;remove urms
    % choice==3;remove |cw-u|
    % choice==4;remove gamma
    % choice==5;four properties are used
clearvars -except season choice
cd('.../normalized_input_data');
if season==1
load(['normalized_original_data_fall.mat']);
elseif season==2
load(['normalized_original_data_winter.mat']);
elseif season==3
load(['normalized_original_data_spring.mat']);
elseif season==4
load(['normalized_original_data_summer.mat']);
elseif season==5
load(['normalized_original_data_annualmean.mat']);
end

normchoice=3;% the choice of normalization typy: Z-score 
p1=p1(:,:,normchoice);% leddy
p2=p2(:,:,normchoice);% urms
p3=p3(:,:,normchoice);% |cw-u|
p4=p4(:,:,normchoice);% gamma
y=y(:,:,normchoice);
mask=p1.*p2.*p3.*p4.*y;
mask(isfinite(mask))=1;

    if choice==1
        clear X2;
X2(:,1)=p2(isfinite(mask));
X2(:,2)=p3(isfinite(mask));
X2(:,3)=p4(isfinite(mask));
    elseif choice==2
        clear X2;
X2(:,1)=p1(isfinite(mask));
X2(:,2)=p3(isfinite(mask));
X2(:,3)=p4(isfinite(mask));
    elseif choice==3
        clear X2;
X2(:,1)=p1(isfinite(mask));
X2(:,2)=p2(isfinite(mask));
X2(:,3)=p4(isfinite(mask));
    elseif choice==4
        clear X2;
X2(:,1)=p1(isfinite(mask));
X2(:,2)=p2(isfinite(mask));
X2(:,3)=p3(isfinite(mask));
    elseif choice==5
    clear X2;
X2(:,1)=p1(isfinite(mask));
X2(:,2)=p2(isfinite(mask));
X2(:,3)=p3(isfinite(mask));
X2(:,4)=p4(isfinite(mask));
    end
Y2=y(isfinite(mask));
xlocation=xc(isfinite(mask));
ylocation=yc(isfinite(mask));

% Repeat network calculations and changes randomly the training data set
for netrepeat=1:100
% Percentage X are used for training
for npercentage=1:5:96
clearvars -except season npercentage X2 Y2 xlocation ylocation choice netrepeat; 
  
[N,D] =size(X2);
randvector = randperm(N);  
n=round(size(X2,1)*npercentage/100.0);

XTrain= X2(randvector(1:n),:);
YTrain= Y2(randvector(1:n));
XTest = X2(randvector(n+1:end),:);
YTest= Y2(randvector(n+1:end));
xloc_test=xlocation(randvector(n+1:end));
yloc_test=ylocation(randvector(n+1:end));

dirs=('...\RF_MexStandalone-v0.02-precompiled\randomforest-matlab\RF_Reg_C');
addpath(dirs);
cd(dirs);

if strcmpi(computer,'PCWIN') |strcmpi(computer,'PCWIN64')
   compile_windows
else
   compile_linux
end

total_train_time=0;
total_test_time=0;

model2 = regRF_train(XTrain,YTrain);
Y2_hat= regRF_predict(XTest,model2);

YPredicted=Y2_hat;

% Denormalization
cd('.../original_data');
if season==1
load(['cross_original_data_0.2regulargrid_fall.mat'],'Lmix');
elseif season==2
load(['cross_original_data_0.2regulargrid_winter.mat'],'Lmix');
elseif season==3
load(['cross_original_data_0.2regulargrid_spring.mat'],'Lmix');
elseif season==4
load(['cross_original_data_0.2regulargrid_summer.mat'],'Lmix');
elseif season==5
load(['cross_original_data_0.2regulargrid_fall.mat'],'Lmix');
end

y_0=Lmix;clear Lmix;
ypred=YPredicted.*nanstd(y_0(:))+nanmean(y_0(:));
yvalid=YTest.*nanstd(y_0(:))+nanmean(y_0(:));

% Correlation
vel1=ypred;
vel2=yvalid;
NN_boot=50;
N_boot=round(length(ypred)/NN_boot);
temp1=vel1;temp2=vel2;
VEL1=temp1(isfinite(vel1.*vel2));
VEL2=temp2(isfinite(vel1.*vel2));
%------------------ordinary correlation------------------------------------
[R1,P1,RL1,RU1] = corrcoef(VEL1-mean(VEL1), VEL2-mean(VEL2));
R=R1(1,2);
%---errorbar of ordinary correlation through bootstraping technique--------
for nrepeat=1:N_boot
    nindex=randperm(size(VEL1,1)*size(VEL1,2),NN_boot);
    [R1,P1,RL1,RU1] = corrcoef(VEL1(nindex)-mean(VEL1(nindex)),VEL2(nindex)-mean(VEL2(nindex)));
    R_boot(nrepeat)=R1(1,2); 
end
error_R=2*std((squeeze(R_boot(:))),0,1)/sqrt(N_boot);

% Skill
skill=1-sqrt(nanmean((ypred-yvalid).^2)/(nanmean(yvalid.^2)));

cd('...');
save(['cross_prediction_forRF_netrepeat',num2str(netrepeat),'_season',num2str(season),...
    '_dischoice',num2str(choice),'_degree1_delta0.35_traningpercentage',num2str(npercentage),'.mat'],...
    'ypred','yvalid','yloc_test','xloc_test','R','error_R','skill','randvector');
end
end
end
end
