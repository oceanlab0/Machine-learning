%The modeling was done with Matlab software version R2019a.
clear;clc;close all;
for season=1:5
% Percentage used for validation
for percent=99:-5:4
% Repeat network calculations
for netrepeat=1:100
   clearvars -except season percent netrepeat

picturesize=10;%  Size of each picture: picturesize^2
landchoice=2;%1: get rid of picture with 1 or more land points, 
nanpercent=35;%2: get rid of picture with more than nanpercent% land points
normchoice=3;% choice of normalization typy: Z-score

cd('.../normalized_input_data');
if season==1
load(['normalized_original_data_fall.mat']);
elseif season==2
load(['normalized_original_data_winter.mat']);
elseif season==3
load(['normalized_original_data_spring.mat']);
elseif season==4
load(['normalized_original_data_summer.mat']);
elseif season==5
load(['normalized_original_data_annualmean.mat']);
end
x1=p1(:,:,normchoice);x1_0=x1;
x2=p2(:,:,normchoice);x2_0=x2;
x3=p3(:,:,normchoice);x3_0=x3;
x4=p4(:,:,normchoice);x4_0=x4;
Y=y(:,:,normchoice);Y_0=Y;
N=0;
pictureres=picturesize; % validation data without overlapping
for i=1:pictureres:size(x1,1)+1-picturesize
    for j=1:pictureres:size(x1,2)+1-picturesize
temp1=x1(i:i+picturesize-1,j:j+picturesize-1);
temp2=x2(i:i+picturesize-1,j:j+picturesize-1);
temp3=x3(i:i+picturesize-1,j:j+picturesize-1);
temp4=x4(i:i+picturesize-1,j:j+picturesize-1);
temp5=Y(i:i+picturesize-1,j:j+picturesize-1);
tempxx=xc(i:i+picturesize-1,j:j+picturesize-1);
tempyy=yc(i:i+picturesize-1,j:j+picturesize-1);

mask=temp1.*temp2.*temp3.*temp4.*temp5;
mask(isfinite(mask))=1;mask(isnan(mask))=0;
    if(sum(mask(:))/(size(mask,1)*size(mask,2)) > 1-nanpercent/100.0)  
            N=N+1;
            in(N)=i;jn(N)=j;
% Fill 'NaN' with the averaged value
temp1(isnan(temp1))=nanmean(temp1(:));x_picture_valid(:,:,1,N)=temp1;
temp2(isnan(temp2))=nanmean(temp2(:));x_picture_valid(:,:,2,N)=temp2;
temp3(isnan(temp3))=nanmean(temp3(:));x_picture_valid(:,:,3,N)=temp3;
temp4(isnan(temp4))=nanmean(temp4(:));x_picture_valid(:,:,4,N)=temp4;    
    cd('.../code');% spacial averaged value
    y_picture_valid(N,1)=spacial_ave(temp5,tempxx,tempyy);
    xlocation_valid(N,1)=xc(i+floor(picturesize/2),j+floor(picturesize/2));
    ylocation_valid(N,1)=yc(i+floor(picturesize/2),j+floor(picturesize/2));
    else
    end       
    end
end

% change randomly the training data set
rand1=randperm(N);

% select validation data
valid_percentage=percent;
m1=round(size(rand1,2)*valid_percentage/100.0);

xcenter_valid=xlocation_valid(rand1(1:m1),1);
ycenter_valid=ylocation_valid(rand1(1:m1),1);

XTest=x_picture_valid(:,:,:,rand1(1:m1),1);
YTest=y_picture_valid(rand1(1:m1),1);

% Assign a special value ('sp') to the selected picture on the original picture
sp=100;
for h=1:m1
    x1(in(rand1(h)):in(rand1(h))+picturesize-1,jn(rand1(h)):jn(rand1(h))+picturesize-1)=ones(picturesize,picturesize).*sp;
    x2(in(rand1(h)):in(rand1(h))+picturesize-1,jn(rand1(h)):jn(rand1(h))+picturesize-1)=ones(picturesize,picturesize).*sp;
    x3(in(rand1(h)):in(rand1(h))+picturesize-1,jn(rand1(h)):jn(rand1(h))+picturesize-1)=ones(picturesize,picturesize).*sp;
    x4(in(rand1(h)):in(rand1(h))+picturesize-1,jn(rand1(h)):jn(rand1(h))+picturesize-1)=ones(picturesize,picturesize).*sp;
    Y(in(rand1(h)):in(rand1(h))+picturesize-1,jn(rand1(h)):jn(rand1(h))+picturesize-1)=ones(picturesize,picturesize).*sp;
end

% new picture
clear x_picture y_picture��
N=0;
pictureres=1;%Increase the number of training set samples, which are partially overlapping

for i=1:pictureres:size(x1,1)+1-picturesize
    for j=1:pictureres:size(x1,2)+1-picturesize
clear temp1;temp1=x1(i:i+picturesize-1,j:j+picturesize-1);
clear temp2;temp2=x2(i:i+picturesize-1,j:j+picturesize-1);
clear temp3;temp3=x3(i:i+picturesize-1,j:j+picturesize-1);
clear temp4;temp4=x4(i:i+picturesize-1,j:j+picturesize-1);
clear temp5;temp5=Y(i:i+picturesize-1,j:j+picturesize-1);
clear tempxx;tempxx=xc(i:i+picturesize-1,j:j+picturesize-1);
clear tempyy;tempyy=yc(i:i+picturesize-1,j:j+picturesize-1);

[qx,qy]=find(temp5==sp);
% Control the overlapping part of the training picture and validation picture within 20%
if(size(qx,1)/(size(temp5,1)*size(temp5,2)) < 20/100.0)
    temp1=x1_0(i:i+picturesize-1,j:j+picturesize-1);
    temp2=x2_0(i:i+picturesize-1,j:j+picturesize-1);
    temp3=x3_0(i:i+picturesize-1,j:j+picturesize-1);
    temp4=x4_0(i:i+picturesize-1,j:j+picturesize-1);
    temp5=Y_0(i:i+picturesize-1,j:j+picturesize-1);
% Judging the number of land points
mask=temp1.*temp2.*temp3.*temp4.*temp5;
mask(isfinite(mask))=1;mask(isnan(mask))=0;
    if(sum(mask(:))/(size(mask,1)*size(mask,2)) > 1-nanpercent/100.0)  
            N=N+1;
% Fill 'NaN' with the averaged value
temp1(isnan(temp1))=nanmean(temp1(:));x_picture(:,:,1,N)=temp1;
temp2(isnan(temp2))=nanmean(temp2(:));x_picture(:,:,2,N)=temp2;
temp3(isnan(temp3))=nanmean(temp3(:));x_picture(:,:,3,N)=temp3;
temp4(isnan(temp4))=nanmean(temp4(:));x_picture(:,:,4,N)=temp4;    
    cd('.../code');% spacial averaged value
    y_picture(N,1)=spacial_ave(temp5,tempxx,tempyy);
    xlocation(N,1)=xc(i+floor(picturesize/2),j+floor(picturesize/2));
    ylocation(N,1)=yc(i+floor(picturesize/2),j+floor(picturesize/2));
    else
    end
else
end
    end
end        

x2_picture=x_picture;XTest2=XTest;clear x_picture XTest;
for choice=1:5
    % choice==1;remove leddy
    % choice==2;remove urms
    % choice==3;remove |cw-u|
    % choice==4;remove gamma
    % choice==5;four properties are used
    if choice==1;x_picture=x2_picture(:,:,2:4,:);XTest=XTest2(:,:,2:4,:);dimension=3;
    elseif choice==2;x_picture=x2_picture(:,:,[1,3,4],:);XTest=XTest2(:,:,[1,3,4],:);dimension=3;
    elseif choice==3;x_picture=x2_picture(:,:,[1,2,4],:);XTest=XTest2(:,:,[1,2,4],:);dimension=3;
    elseif choice==4;x_picture=x2_picture(:,:,1:3,:);XTest=XTest2(:,:,1:3,:);dimension=3;
    elseif choice==5;x_picture=x2_picture(:,:,1:4,:);XTest=XTest2(:,:,1:4,:);dimension=4;
    end

%change randomly the training data set   
randvector=randperm(N);

% Percentage X are used for training
npercentage=100;

m=round(size(randvector,2)*npercentage/100.0);
XTrain=x_picture(:,:,:,randvector(1:m));
YTrain=y_picture(randvector(1:m),1);
xcenter_train=xlocation(randvector(1:m),1);
ycenter_train=ylocation(randvector(1:m),1);

filterSize=2;
numFilters=8;

layers = [
    imageInputLayer([picturesize picturesize dimension])
    convolution2dLayer(filterSize,numFilters,'Padding','same')%1st convolutional layer
    batchNormalizationLayer
	reluLayer
	
    averagePooling2dLayer(2, 'Stride', 1)
	
	convolution2dLayer(filterSize, numFilters*2, 'Padding', 'same')%2nd convolutional layer
	batchNormalizationLayer
	reluLayer
	
	averagePooling2dLayer(2, 'Stride', 1)
	
	convolution2dLayer(filterSize, numFilters*4, 'Padding', 'same')%3rd convolutional layer
	batchNormalizationLayer
	reluLayer
	
    averagePooling2dLayer(2, 'Stride', 1)
    
	convolution2dLayer(filterSize, numFilters*4, 'Padding', 'same')%4th convolutional layer
	batchNormalizationLayer
	reluLayer

    averagePooling2dLayer(2, 'Stride', 1)
    
	convolution2dLayer(filterSize, numFilters*4, 'Padding', 'same')%5th convolutional layer
	batchNormalizationLayer
	reluLayer
    
	dropoutLayer(0.2)
	fullyConnectedLayer(1)
	regressionLayer];

if(length(YTrain)>5000)
    maxepochs=100;
elseif(length(YTrain)>1000 & length(YTrain)<=5000)
    maxepochs=50;
else
    maxepochs=10;
end
miniBatchSize = round(numel(YTrain)/maxepochs);
validationFrequency = round(numel(YTrain) /miniBatchSize);

options = trainingOptions('adam', ...
	 'MiniBatchSize', miniBatchSize, ...
	 'MaxEpochs', maxepochs, ...
	 'InitialLearnRate', 1e-4, ...
	 'LearnRateSchedule', 'none', ...
                  'Shuffle', 'every-epoch', ...
                  'Verbose', true);
net = trainNetwork(XTrain, YTrain, layers, options);

YPredicted=predict(net,XTest);

% Denormalization
cd('.../original_data');
if season==1
load(['cross_original_data_0.2regulargrid_fall.mat'],'Lmix');
elseif season==2
load(['cross_original_data_0.2regulargrid_winter.mat'],'Lmix');
elseif season==3
load(['cross_original_data_0.2regulargrid_spring.mat'],'Lmix');
elseif season==4
load(['cross_original_data_0.2regulargrid_summer.mat'],'Lmix');
elseif season==5
load(['cross_original_data_0.2regulargrid_fall.mat'],'Lmix');
end

y_0=Lmix;clear Lmix;
ypred=YPredicted.*nanstd(y_0(:))+nanmean(y_0(:));
yvalid=YTest.*nanstd(y_0(:))+nanmean(y_0(:));

% Correlation    
vel1=ypred;
vel2=yvalid;
if(percent==4 || percent==9 || percent==14 || percent==19)
NN_boot=3;
elseif(percent==24 || percent==29 || percent==34 || percent==39)
NN_boot=10;
else
NN_boot=20;
end
N_boot=round(length(ypred)/NN_boot);
temp1=vel1;temp2=vel2;
VEL1=temp1(isfinite(vel1.*vel2));
VEL2=temp2(isfinite(vel1.*vel2));
%------------------ordinary correlation------------------------------------
[R1,P1,RL1,RU1] = corrcoef(VEL1-mean(VEL1), VEL2-mean(VEL2));
R=R1(1,2);
%---errorbar of ordinary correlation through bootstraping technique--------
for nrepeat=1:N_boot
    nindex=randperm(size(VEL1,1)*size(VEL1,2),NN_boot);
    [R1,P1,RL1,RU1] = corrcoef(VEL1(nindex)-mean(VEL1(nindex)),VEL2(nindex)-mean(VEL2(nindex)));
    R_boot(nrepeat)=R1(1,2); 
end
error_R=2*std((squeeze(R_boot(:))),0,1)/sqrt(N_boot);

% Skill
skill=1-sqrt(nanmean((ypred-yvalid).^2)/(nanmean(yvalid.^2)));

cd('...');
save(['cross_prediction_forCNN_netrepeat',num2str(netrepeat),'_season',num2str(season),...
    '_dischoice',num2str(choice),'_degree1_delta0.35_traningpercentage',num2str(100-percent),'.mat'],...
    'filterSize','maxepochs','numFilters',...
    'percent','rand1','randvector',...
    'YPredicted','ypred','R','error_R','skill',...
    'YTest','yvalid',...
    'xcenter_valid','ycenter_valid',...
    'normchoice','picturesize','landchoice','nanpercent',...
    'NN_boot','N_boot');
end
end
end
end