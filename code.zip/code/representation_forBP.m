%The modeling was done with Matlab software version R2019a.
clear;clc;close all;
for season=1:5
clearvars -except season
cd('.../normalized_input_data');
if season==1
load(['normalized_original_data_fall.mat']);
elseif season==2
load(['normalized_original_data_winter.mat']);
elseif season==3
load(['normalized_original_data_spring.mat']);
elseif season==4
load(['normalized_original_data_summer.mat']);
elseif season==5
load(['normalized_original_data_annualmean.mat']);
end

norm=3;% the choice of normalization typy: Z-score 
p1=p1(:,:,norm);%Leddy
p2=p2(:,:,norm);%urms
p3=p3(:,:,norm);%|cw-u|
p4=p4(:,:,norm);%gamma
y=y(:,:,norm);
mask=p1.*p2.*p3.*p4.*y;
mask(isfinite(mask))=1;

for choice=1:5
    % choice==1;remove leddy
    % choice==2;remove urms
    % choice==3;remove |cw-u|
    % choice==4;remove gamma
    % choice==5;four properties are used
    if choice==1
    clear X2;
X2(:,1)=p2(isfinite(mask));
X2(:,2)=p3(isfinite(mask));
X2(:,3)=p4(isfinite(mask));
    elseif choice==2
    clear X2;
X2(:,1)=p1(isfinite(mask));
X2(:,2)=p3(isfinite(mask));
X2(:,3)=p4(isfinite(mask));
    elseif choice==3
    clear X2;
X2(:,1)=p1(isfinite(mask));
X2(:,2)=p2(isfinite(mask));
X2(:,3)=p4(isfinite(mask));
    elseif choice==4
    clear X2;
X2(:,1)=p1(isfinite(mask));
X2(:,2)=p2(isfinite(mask));
X2(:,3)=p3(isfinite(mask));
    elseif choice==5
    clear X2;
X2(:,1)=p1(isfinite(mask));
X2(:,2)=p2(isfinite(mask));
X2(:,3)=p3(isfinite(mask));
X2(:,4)=p4(isfinite(mask));
    end

Y2=y(isfinite(mask));
xlocation=xc(isfinite(mask));
ylocation=yc(isfinite(mask));

% Repeat network calculations and changes randomly the training data set
for netrepeat=1:1
    
[N,D] =size(X2);
randvector = randperm(N);

% Percentage X are used for training
npercentage=100;

n=round(size(X2,1)*npercentage/100.0);

XTrain=X2(randvector(1:n),:)';
YTrain=Y2(randvector(1:n))';
XTest=XTrain;
YTest=YTrain;
xloc_test=xlocation(randvector(1:n),:);
yloc_test=ylocation(randvector(1:n),:);

% Initialize the network structure
net=newff(XTrain,YTrain,20);
net.trainParam.epochs=100;
net.trainParam.lr=0.05;
net.trainParam.goal=0.000001;

% Trainning
net=train(net,XTrain,YTrain);

% Prediction
YPredicted=sim(net,XTest);%sim:simulate a slmulink model

% Denormalization
cd('.../original_data');
if season==1
load(['cross_original_data_0.2regulargrid_fall.mat'],'Lmix');
elseif season==2
load(['cross_original_data_0.2regulargrid_winter.mat'],'Lmix');
elseif season==3
load(['cross_original_data_0.2regulargrid_spring.mat'],'Lmix');
elseif season==4
load(['cross_original_data_0.2regulargrid_summer.mat'],'Lmix');
elseif season==5
load(['cross_original_data_0.2regulargrid_fall.mat'],'Lmix');
end

y_0=Lmix;clear Lmix;
ypred=YPredicted.*nanstd(y_0(:))+nanmean(y_0(:));
yvalid=YTest.*nanstd(y_0(:))+nanmean(y_0(:));

% Correlation
vel1=ypred';
vel2=yvalid';
NN_boot=50;
N_boot=round(length(ypred)/NN_boot);
temp1=vel1;temp2=vel2;
VEL1=temp1(isfinite(vel1.*vel2));
VEL2=temp2(isfinite(vel1.*vel2));
%------------------ordinary correlation------------------------------------
[R1,P1,RL1,RU1] = corrcoef(VEL1-mean(VEL1), VEL2-mean(VEL2));
R=R1(1,2);
%---errorbar of ordinary correlation through bootstraping technique--------
for nrepeat=1:N_boot
    nindex=randperm(size(VEL1,1)*size(VEL1,2),NN_boot);
    [R1,P1,RL1,RU1] = corrcoef(VEL1(nindex)-mean(VEL1(nindex)),VEL2(nindex)-mean(VEL2(nindex)));
    R_boot(nrepeat)=R1(1,2); 
end
error_R=2*std((squeeze(R_boot(:))),0,1)/sqrt(N_boot);

% Skill
skill=1-sqrt(nanmean((ypred-yvalid).^2)/(nanmean(yvalid.^2)));

cd('...');
save(['cross_representation_forBP_netrepeat',num2str(netrepeat),'_season',num2str(season),...
    '_dischoice',num2str(choice),'_degree1_delta0.35.mat'],...
    'ypred','yvalid','yloc_test','xloc_test','R','error_R','skill','randvector');
end
end
end