function [vars_spacialave] = spacial_ave(vel1,xc,yc)
box=NaN(size(vel1,1),size(vel1,2));
temparea1=ones(size(vel1,1),size(vel1,2));temparea1(isnan(vel1))=NaN;
for i=1:size(vel1,1)-1    
    for j=1:size(vel1,2)-1
        box(i,j)=(6378100.*(xc(i,j+1)-xc(i,j)).*pi/180.*cos(yc(i,j)*pi/180)).*(6378100.*(yc(i+1,j)-yc(i,j)).*pi/180);
    end
end
vars_spacialave=nansum(nansum(vel1.*box))/nansum(nansum(temparea1.*box));
end

